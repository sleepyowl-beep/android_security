package com.williams.zipslip;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class MainActivity extends AppCompatActivity {

    private EditText name,secret = null;
    private Button save,update,secure_update = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = (EditText)findViewById(R.id.editText);
        secret = (EditText)findViewById(R.id.editText3);
        save = (Button)findViewById(R.id.Save_button);
        update = (Button)findViewById(R.id.Update_button);
        secure_update = (Button)findViewById(R.id.secure_update_button);

        final SharedPreferences prefs = getSharedPreferences("data",MODE_PRIVATE);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name_pref = name.getText().toString();
                String secret_pref = secret.getText().toString();

                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("name",name_pref);
                editor.putString("secret",secret_pref);
                editor.commit();
                Toast.makeText(MainActivity.this,"Thank you",Toast.LENGTH_LONG).show();
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    extractzipfile("/storage/emulated/0/update.zip");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        secure_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    secure_extractzipfile("/storage/emulated/0/update.zip");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void extractzipfile(String zipfilepath) throws IOException {
        File zipfile = new File(zipfilepath);
        ZipFile zip = new ZipFile(zipfile);
        String dstdir = zipfile.getParent();


        Enumeration zipfilentries = zip.entries();
        while (zipfilentries.hasMoreElements()){
            ZipEntry entry = (ZipEntry) zipfilentries.nextElement();
            File destfile = new File(dstdir,entry.getName());
            destfile.getParentFile().mkdirs();

            if(!entry.isDirectory()){
                BufferedInputStream is = new BufferedInputStream(zip.getInputStream(entry));
                byte[] data = new byte[2048];
                BufferedOutputStream dest = new BufferedOutputStream(new FileOutputStream(destfile),2048);
                while (true){
                    int read = is.read(data,0,2048);
                    int currentByte = read;
                    if(read == -1){
                        break;
                    }
                    dest.write(data,0,currentByte);
                }
                dest.flush();
                dest.close();
                is.close();
            }

        }

    }

    private void secure_extractzipfile(String zipfilepath) throws Exception {
        File zipfile = new File(zipfilepath);
        ZipFile zip = new ZipFile(zipfile);
        String dstdir = zipfile.getCanonicalPath();


        Enumeration zipfilentries = zip.entries();
        while (zipfilentries.hasMoreElements()){
            ZipEntry entry = (ZipEntry) zipfilentries.nextElement();
            File destfile = new File(dstdir,entry.getName());
            String canondestpathfile = destfile.getCanonicalPath();

            if(!canondestpathfile.startsWith(canondestpathfile + File.separator)){
                throw new Exception("Entry is outside of the target dir: " + entry.getName());
            }

            destfile.getParentFile().mkdirs();

            if(!entry.isDirectory()){
                BufferedInputStream is = new BufferedInputStream(zip.getInputStream(entry));
                byte[] data = new byte[2048];
                BufferedOutputStream dest = new BufferedOutputStream(new FileOutputStream(destfile),2048);
                while (true){
                    int read = is.read(data,0,2048);
                    int currentByte = read;
                    if(read == -1){
                        break;
                    }
                    dest.write(data,0,currentByte);
                }
                dest.flush();
                dest.close();
                is.close();
            }

        }

    }
}
