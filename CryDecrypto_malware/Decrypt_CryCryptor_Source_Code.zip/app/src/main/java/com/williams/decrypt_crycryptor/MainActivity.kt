package com.williams.decrypt_crycryptor

import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var textDetectingMalware:TextView
    private lateinit var buttonDecryptingFile:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textDetectingMalware = findViewById<TextView>(R.id.check_malware)
        buttonDecryptingFile = findViewById<Button>(R.id.decrypt_file)

        if(detectRansomware()){
            textDetectingMalware.text = "Malware: is installed"
            buttonDecryptingFile.setOnClickListener {
                decryptFile()
            }
        }else{
            buttonDecryptingFile.isClickable = false
            buttonDecryptingFile.visibility = View.INVISIBLE
        }

    }

    fun detectRansomware():Boolean{
        var pm = packageManager
        try{
            pm.getPackageInfo("com.crydroid",PackageManager.GET_ACTIVITIES)
            return true
        }catch (e: PackageManager.NameNotFoundException){
            return false
        }

    }

    fun decryptFile(){
        var intent = Intent()
        intent.setClassName("com.crydroid","com.crydroid.services.DecryptionService")
        startService(intent)
        Toast.makeText(this,"Done! Decrypting your file :)",Toast.LENGTH_LONG).show()
    }
}
